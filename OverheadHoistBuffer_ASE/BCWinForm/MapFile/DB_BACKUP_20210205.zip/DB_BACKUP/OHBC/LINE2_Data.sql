USE [OHBC_ASE_K21_LINE2]
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10000', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10001', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10002', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10003', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10004', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10005', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10006', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10007', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10008', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10009', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10010', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10011', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10012', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10013', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10014', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10015', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10016', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10017', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10018', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10019', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10020', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10021', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10022', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10023', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10024', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10025', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10026', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10027', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10028', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10029', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10030', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10031', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10032', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10033', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10034', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10035', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10036', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10037', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10038', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10039', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10040', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10041', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10042', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10043', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10044', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10045', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10046', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10047', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10048', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10049', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10050', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10051', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10052', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10053', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10054', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10055', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10056', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10057', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10058', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10059', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[AADDRESS] ([ADR_ID], [ADRTYPE], [SEC_ID], [DISTANCE], [CS_NUMBER], [T_PULSE], [P_LOCATION], [IS_DISPLAY], [ZOOM_LV], [BAR_CODE], [OFFSET_X], [OFFSET_Y], [OFFSET_Z], [OFFSET_T], [PIO_ID], [PIO_CHN], [PORT1_ID], [P1_LD_VH_TYPE], [P1_ULD_VH_TYPE], [PORT2_ID], [P2_LD_VH_TYPE], [P2_ULD_VH_TYPE]) VALUES (N'10060', 1, NULL, NULL, N'          ', N'          ', N'          ', 1, 10, N'5319      ', 0, 0, 0, 0, N'      ', 0, N'          ', 0, 0, N'          ', 0, 0)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'001', N'2  ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'002', N'1  ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'003', N'2  ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'051', N'51 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'052', N'52 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'053', N'2  ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'054', N'2  ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'055', N'2  ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'056', N'2  ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'057', N'2  ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'101', N'103', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'102', N'103', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'103', N'103', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'104', N'103', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'105', N'103', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'106', N'103', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'107', N'104', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'108', N'105', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'109', N'103', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'110', N'103', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'111', N'110', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'151', N'106', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'152', N'106', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'153', N'107', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'154', N'108', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'155', N'106', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'156', N'109', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'157', N'205', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'158', N'106', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'159', N'208', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'161', N'111', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'162', N'31 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'163', N'31 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'113', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'202', N'113', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'203', N'207', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'204', N'207', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'205', N'207', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'206', N'207', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'251', N'114', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'252', N'112', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'253', N'211', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'254', N'117', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'255', N'208', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'256', N'209', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'257', N'213', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'260', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'261', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'263', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'264', N'210', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'602', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'603', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'604', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'701', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'702', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACEID] ([CEID], [RPTID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'703', N'12 ', 1, NULL, NULL)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY001     ', N'0002      ', 6)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY001     ', N'0004      ', 1)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY001     ', N'0005      ', 2)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY001     ', N'0006      ', 5)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY001     ', N'0201      ', 3)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY001     ', N'0202      ', 4)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0001      ', 1)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0002      ', 2)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0003      ', 3)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0007      ', 4)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0008      ', 5)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0010      ', 6)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0012      ', 7)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0014      ', 8)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0027      ', 9)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0028      ', 10)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0029      ', 11)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0040      ', 12)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0041      ', 13)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0042      ', 14)
GO
INSERT [dbo].[ACYCLEZONEDETAIL] ([CYCLE_ZONE_ID], [SEC_ID], [SEC_ORDER]) VALUES (N'CY002     ', N'0043      ', 15)
GO
INSERT [dbo].[ACYCLEZONEMASTER] ([CYCLE_TYPE_ID], [CYCLE_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER]) VALUES (N'CID001    ', N'CY001     ', 0, N'10299', 3)
GO
INSERT [dbo].[ACYCLEZONETYPE] ([CYCLE_TYPE_ID], [PROD_ID], [TOTAL_BORDER], [IS_DEFAULT]) VALUES (N'CID000    ', NULL, 0, 1)
GO
INSERT [dbo].[ACYCLEZONETYPE] ([CYCLE_TYPE_ID], [PROD_ID], [TOTAL_BORDER], [IS_DEFAULT]) VALUES (N'CID001    ', N'PID001    ', 3, 0)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'CV31_A         ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'CV31_B         ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'CV32_A         ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'CV32_B         ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'CV61_A         ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'CV61_B         ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'CV62_A         ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'CV62_B         ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'EQ1            ', N'EQ_NODE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'HID            ', N'VH_LINE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'HID2           ', N'VH_LINE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'HID3           ', N'VH_LINE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'HID4           ', N'VH_LINE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'MTL            ', N'VH_LINE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'MTS            ', N'VH_LINE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'MTS2           ', N'VH_LINE        ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'PORT_EQ        ', N'PORT_NODE      ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AEQPT] ([EQPT_ID], [NODE_ID], [CIM_MODE], [OPER_MODE], [INLINE_MODE], [EQPT_STAT], [EQPT_PROC_STAT], [CR_RECIPE], [MAX_SHT_CNT], [MIN_SHT_CNT], [ALARM_STAT], [WARN_STAT]) VALUES (N'TEST           ', N'TEST           ', N' ', N' ', N' ', N' ', N' ', NULL, 0, 0, NULL, NULL)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01001', N'0001 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01002', N'0002 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01003', N'0003 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01004', N'0004 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01005', N'0005 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01006', N'0006 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01007', N'0007 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01008', N'0008 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01009', N'0009 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01010', N'0010 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01011', N'0011 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01012', N'0012 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01013', N'0013 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01014', N'0014 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01015', N'0015 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01016', N'0016 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01017', N'0017 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01018', N'0018 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01019', N'0019 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01020', N'0020 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01021', N'0021 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01022', N'0022 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01023', N'0023 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01024', N'0024 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01025', N'0025 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01026', N'0026 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01027', N'0027 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01028', N'0028 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01029', N'0029 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01030', N'0030 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01031', N'0031 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01032', N'0032 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01033', N'0033 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01034', N'0034 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01035', N'0035 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01036', N'0036 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01037', N'0037 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01038', N'0038 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01039', N'0039 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01040', N'0040 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01041', N'0041 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01042', N'0042 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01043', N'0043 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01044', N'0044 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01045', N'0045 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01046', N'0046 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01047', N'0047 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01048', N'0048 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01049', N'0049 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01050', N'0050 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01051', N'0051 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01052', N'0052 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01053', N'0053 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01054', N'0054 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01055', N'0055 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01056', N'0056 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01057', N'0057 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01058', N'0058 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01059', N'0059 ', 1, 1)
GO
INSERT [dbo].[AGROUPRAILS] ([SECTION_ID], [RAIL_ID], [RAIL_NO], [DIR]) VALUES (N'01060', N'0060 ', 1, 1)
GO
INSERT [dbo].[AHIDZONEDETAIL] ([ENTRY_SEC_ID], [SEC_ID]) VALUES (N'0043 ', N'0001 ')
GO
INSERT [dbo].[AHIDZONEDETAIL] ([ENTRY_SEC_ID], [SEC_ID]) VALUES (N'0043 ', N'0002 ')
GO
INSERT [dbo].[AHIDZONEDETAIL] ([ENTRY_SEC_ID], [SEC_ID]) VALUES (N'0043 ', N'0003 ')
GO
INSERT [dbo].[AHIDZONEDETAIL] ([ENTRY_SEC_ID], [SEC_ID]) VALUES (N'0043 ', N'0004 ')
GO
INSERT [dbo].[AHIDZONEDETAIL] ([ENTRY_SEC_ID], [SEC_ID]) VALUES (N'0043 ', N'0005 ')
GO
INSERT [dbo].[AHIDZONEDETAIL] ([ENTRY_SEC_ID], [SEC_ID]) VALUES (N'0043 ', N'0006 ')
GO
INSERT [dbo].[AHIDZONEDETAIL] ([ENTRY_SEC_ID], [SEC_ID]) VALUES (N'0043 ', N'0043 ')
GO
INSERT [dbo].[AHIDZONEDETAIL] ([ENTRY_SEC_ID], [SEC_ID]) VALUES (N'0043 ', N'0202 ')
GO
INSERT [dbo].[AHIDZONEMASTER] ([ENTRY_SEC_ID], [LEAVE_ADR_ID_1], [LEAVE_ADR_ID_2], [MAX_LOAD_COUNT]) VALUES (N'0043 ', N'10401', NULL, 2)
GO
INSERT [dbo].[ALINE] ([LINE_ID], [HOST_MODE], [LINE_STAT]) VALUES (N'B7_OHBLINE2    ', 0, 0)
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'CV31           ', N'VH_LINE        ')
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'CV32           ', N'VH_LINE        ')
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'CV61           ', N'VH_LINE        ')
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'CV62           ', N'VH_LINE        ')
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'EQ_NODE        ', N'VH_LINE        ')
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'HID_NODE       ', N'VH_LINE        ')
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'PORT_NODE      ', N'VH_LINE        ')
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'TEST           ', N'VH_LINE        ')
GO
INSERT [dbo].[ANODE] ([NODE_ID], [ZONE_ID]) VALUES (N'VH_LINE        ', N'VH_LINE        ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_1     ', N'20198', 13, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_1     ', N'20202', 12, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_1     ', N'20207', 11, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_3-4   ', N'20168', 12, N'OHx01')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_3-4   ', N'20172', 11, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_5-6   ', N'20113', 12, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_5-6   ', N'20117', 11, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_7-8   ', N'20082', 12, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_7-8   ', N'20087', 11, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_9-10  ', N'20031', 12, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'BAY_9-10  ', N'20035', 11, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'STK_300_1 ', N'20280', 11, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'STK_300_2 ', N'20286', 11, N'     ')
GO
INSERT [dbo].[APARKZONEDETAIL] ([PARK_ZONE_ID], [ADR_ID], [PRIO], [CAR_ID]) VALUES (N'STK_600   ', N'20298', 11, N'OHx03')
GO
INSERT [dbo].[APARKZONEMASTER] ([PARK_TYPE_ID], [PARK_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER], [LOWER_BORDER], [PARK_TYPE], [IS_ACTIVE]) VALUES (N'CSOT_1    ', N'BAY_1     ', 0, N'20198', 3, 1, 2, 1)
GO
INSERT [dbo].[APARKZONEMASTER] ([PARK_TYPE_ID], [PARK_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER], [LOWER_BORDER], [PARK_TYPE], [IS_ACTIVE]) VALUES (N'CSOT_1    ', N'BAY_3-4   ', 0, N'20168', 2, 1, 2, 1)
GO
INSERT [dbo].[APARKZONEMASTER] ([PARK_TYPE_ID], [PARK_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER], [LOWER_BORDER], [PARK_TYPE], [IS_ACTIVE]) VALUES (N'CSOT_1    ', N'BAY_5-6   ', 0, N'20113', 2, 1, 2, 1)
GO
INSERT [dbo].[APARKZONEMASTER] ([PARK_TYPE_ID], [PARK_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER], [LOWER_BORDER], [PARK_TYPE], [IS_ACTIVE]) VALUES (N'CSOT_1    ', N'BAY_7-8   ', 0, N'20086', 2, 1, 1, 1)
GO
INSERT [dbo].[APARKZONEMASTER] ([PARK_TYPE_ID], [PARK_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER], [LOWER_BORDER], [PARK_TYPE], [IS_ACTIVE]) VALUES (N'CSOT_1    ', N'BAY_9-10  ', 0, N'20033', 3, 1, 1, 1)
GO
INSERT [dbo].[APARKZONEMASTER] ([PARK_TYPE_ID], [PARK_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER], [LOWER_BORDER], [PARK_TYPE], [IS_ACTIVE]) VALUES (N'CSOT_1    ', N'STK_300_1 ', 0, N'20280', 1, 1, 2, 1)
GO
INSERT [dbo].[APARKZONEMASTER] ([PARK_TYPE_ID], [PARK_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER], [LOWER_BORDER], [PARK_TYPE], [IS_ACTIVE]) VALUES (N'CSOT_1    ', N'STK_300_2 ', 0, N'20286', 1, 1, 2, 1)
GO
INSERT [dbo].[APARKZONEMASTER] ([PARK_TYPE_ID], [PARK_ZONE_ID], [VEHICLE_TYPE], [ENTRY_ADR_ID], [TOTAL_BORDER], [LOWER_BORDER], [PARK_TYPE], [IS_ACTIVE]) VALUES (N'CSOT_1    ', N'STK_600   ', 0, N'20298', 1, 1, 2, 1)
GO
INSERT [dbo].[APARKZONETYPE] ([PARK_TYPE_ID], [PROD_ID], [TOTAL_BORDER], [IS_DEFAULT]) VALUES (N'CSOT_1    ', N'no        ', 15, 1)
GO
INSERT [dbo].[APARKZONETYPE] ([PARK_TYPE_ID], [PROD_ID], [TOTAL_BORDER], [IS_DEFAULT]) VALUES (N'PT000     ', N'P000      ', 0, 0)
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10000', N'10000', NULL, 1, 48, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10001', N'10001', NULL, 1, 128, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10002', N'10002', NULL, 1, 141, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10003', N'10003', NULL, 1, 154, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10004', N'10004', NULL, 1, 167, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10005', N'10005', NULL, 1, 186, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10006', N'10006', NULL, 1, 199, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10007', N'10007', NULL, 1, 212, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10008', N'10008', NULL, 1, 225, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10009', N'10009', NULL, 1, 270, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10010', N'10010', NULL, 1, 320, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10011', N'10011', NULL, 1, 333, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10012', N'10012', NULL, 1, 346, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10013', N'10013', NULL, 1, 359, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10014', N'10014', NULL, 1, 378, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10015', N'10015', NULL, 1, 391, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10016', N'10016', NULL, 1, 404, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10017', N'10017', NULL, 1, 417, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10018', N'10018', NULL, 1, 436, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10019', N'10019', NULL, 1, 449, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10020', N'10020', NULL, 1, 462, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10021', N'10021', NULL, 1, 475, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10022', N'10022', NULL, 1, 480, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10023', N'10023', NULL, 1, 494, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10024', N'10024', NULL, 1, 501, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10025', N'10025', NULL, 1, 513, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10026', N'10026', NULL, 1, 520, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10027', N'10027', NULL, 1, 534, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10028', N'10028', NULL, 1, 541, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10029', N'10029', NULL, 1, 553, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10030', N'10030', NULL, 1, 566, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10031', N'10031', NULL, 1, 579, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10032', N'10032', NULL, 1, 598, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10033', N'10033', NULL, 1, 611, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10034', N'10034', NULL, 1, 624, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10035', N'10035', NULL, 1, 637, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10036', N'10036', NULL, 1, 656, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10037', N'10037', NULL, 1, 669, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10038', N'10038', NULL, 1, 682, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10039', N'10039', NULL, 1, 695, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10040', N'10040', NULL, 1, 714, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10041', N'10041', NULL, 1, 727, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10042', N'10042', NULL, 1, 740, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10043', N'10043', NULL, 1, 753, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10044', N'10044', NULL, 1, 772, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10045', N'10045', NULL, 1, 785, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10046', N'10046', NULL, 1, 798, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10047', N'10047', NULL, 1, 811, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10048', N'10048', NULL, 1, 830, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10049', N'10049', NULL, 1, 843, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10050', N'10050', NULL, 1, 856, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10051', N'10051', NULL, 1, 869, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10052', N'10052', NULL, 1, 888, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10053', N'10053', NULL, 1, 901, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10054', N'10054', NULL, 1, 914, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10055', N'10055', NULL, 1, 927, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10056', N'10056', NULL, 1, 953, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10057', N'10057', NULL, 1, 968, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10058', N'10058', NULL, 1, 983, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10059', N'10059', NULL, 1, 990, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APOINT] ([POINT_ID], [ADR_ID], [RAIL_ID], [POINTTYPE], [LOCATIONX], [LOCATIONY], [HEIGHT], [WIDTH], [COLOR]) VALUES (N'10060', N'10060', NULL, 1, 1006, 150, 8, 8, N'FFDCDCDC  ')
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLINE2_A01', 2, 2, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLINE2_A02', 3, 3, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLINE2_A03', 4, 4, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLINE2_A04', 7, 7, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLINE2_A05', 8, 8, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLINE2_T01', 5, 5, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLINE2_T02', 9, 9, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLINE2_T03', 10, 10, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLOOP_T03 ', 1, 1, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'B7_OHBLOOP_T04 ', 6, 6, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORT] ([PORT_ID], [UNIT_NUM], [PORT_NUM], [EQPT_ID], [PORT_TYPE], [PORT_USE_TYPE], [PORT_REAL_TYPE], [CAPACITY], [PORT_STAT], [PORT_ENABLE], [TRS_MODE]) VALUES (N'MASTER_PLC     ', 20, 20, N'PORT_EQ        ', N'B', NULL, NULL, 0, N' ', N' ', NULL)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100101         ', 0, N'10001', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100201         ', 0, N'10002', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100301         ', 0, N'10003', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100401         ', 0, N'10004', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100501         ', 0, N'10005', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100601         ', 0, N'10006', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100701         ', 0, N'10007', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100801         ', 0, N'10008', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'100901         ', 0, N'10009', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101001         ', 0, N'10010', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101101         ', 0, N'10011', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101201         ', 0, N'10012', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101301         ', 0, N'10013', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101401         ', 0, N'10014', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101501         ', 0, N'10015', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101601         ', 0, N'10016', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101701         ', 0, N'10017', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101801         ', 0, N'10018', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'101901         ', 0, N'10019', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102001         ', 0, N'10020', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102101         ', 0, N'10021', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102201         ', 0, N'10022', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102301         ', 0, N'10023', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102401         ', 0, N'10024', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102501         ', 0, N'10025', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102601         ', 0, N'10026', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102701         ', 0, N'10027', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102801         ', 0, N'10028', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'102901         ', 0, N'10029', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103001         ', 0, N'10030', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103101         ', 0, N'10031', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103201         ', 0, N'10032', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103301         ', 0, N'10033', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103401         ', 0, N'10034', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103501         ', 0, N'10035', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103601         ', 0, N'10036', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103701         ', 0, N'10037', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103801         ', 0, N'10038', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'103901         ', 0, N'10039', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104001         ', 0, N'10040', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104101         ', 0, N'10041', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104201         ', 0, N'10042', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104301         ', 0, N'10043', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104401         ', 0, N'10044', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104501         ', 0, N'10045', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104601         ', 0, N'10046', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104701         ', 0, N'10047', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104801         ', 0, N'10048', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'104901         ', 0, N'10049', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105001         ', 0, N'10050', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105101         ', 0, N'10051', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105201         ', 0, N'10052', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105301         ', 0, N'10053', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105401         ', 0, N'10054', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105501         ', 0, N'10055', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105601         ', 0, N'10056', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105701         ', 0, N'10057', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105801         ', 0, N'10058', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'105901         ', 0, N'10059', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'106001         ', 0, N'10060', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'200101         ', 0, N'10001', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'200201         ', 0, N'10002', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'200301         ', 0, N'10003', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'200401         ', 0, N'10004', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'200501         ', 0, N'10005', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'200601         ', 0, N'10006', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'200701         ', 0, N'10007', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'200801         ', 0, N'10008', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'201701         ', 0, N'10017', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'201801         ', 0, N'10018', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'201901         ', 0, N'10019', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'202001         ', 0, N'10020', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'202101         ', 0, N'10021', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'202201         ', 0, N'10022', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'202301         ', 0, N'10023', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'202401         ', 0, N'10024', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'203601         ', 0, N'10036', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'203701         ', 0, N'10037', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'203801         ', 0, N'10038', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'203901         ', 0, N'10039', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'204001         ', 0, N'10040', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'204101         ', 0, N'10041', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'204201         ', 0, N'10042', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'204301         ', 0, N'10043', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'204401         ', 0, N'10044', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'204501         ', 0, N'10045', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'204601         ', 0, N'10046', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'204701         ', 0, N'10047', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'205601         ', 0, N'10056', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'205701         ', 0, N'10057', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'205801         ', 0, N'10058', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'205901         ', 0, N'10059', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'A01            ', 0, N'20302', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'A02            ', 0, N'20301', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'A03            ', 0, N'10011', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'A04            ', 0, N'10010', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'A05            ', 0, N'10009', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI100A1     ', 0, N'20221', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI100A2     ', 0, N'20220', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI100A3     ', 0, N'20219', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI100A4     ', 0, N'20218', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI100A5     ', 0, N'20217', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI200A6     ', 0, N'20216', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI200A7     ', 0, N'20215', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI200A8     ', 0, N'20214', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI200A9     ', 0, N'20213', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI200AA     ', 0, N'20212', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI300AB     ', 0, N'20211', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI300AC     ', 0, N'20210', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI300AD     ', 0, N'20209', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI300AE     ', 0, N'20208', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI300AF     ', 0, N'20207', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI400AG     ', 0, N'20206', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI400AH     ', 0, N'20205', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI400AJ     ', 0, N'20204', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI400AK     ', 0, N'20203', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI400AL     ', 0, N'20202', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI600F3     ', 0, N'20053', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI600F4     ', 0, N'20052', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI600F5     ', 0, N'20051', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI600F6     ', 0, N'20050', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI600F7     ', 0, N'20049', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI700FY     ', 0, N'20023', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI700FZ     ', 0, N'20022', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI700G1     ', 0, N'20021', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI700G2     ', 0, N'20020', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFAPI700G3     ', 0, N'20019', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFCTP400G4     ', 0, N'20018', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFCTP400G5     ', 0, N'20017', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFCTP400G6     ', 0, N'20016', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFCTP400G7     ', 0, N'20015', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFCTP500G8     ', 0, N'20014', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFCTP500G9     ', 0, N'20013', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFCTP500GA     ', 0, N'20012', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFCTP500GB     ', 0, N'20011', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP100FG     ', 0, N'20039', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP100FH     ', 0, N'20038', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP100FJ     ', 0, N'20037', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP100FK     ', 0, N'20036', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP200FQ     ', 0, N'20031', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP200FR     ', 0, N'20030', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP200FS     ', 0, N'20029', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP200FT     ', 0, N'20028', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP300FC     ', 0, N'20043', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP300FD     ', 0, N'20042', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP300FE     ', 0, N'20041', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP300FF     ', 0, N'20040', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP400FU     ', 0, N'20027', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP400FV     ', 0, N'20026', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP400FW     ', 0, N'20025', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP400FX     ', 0, N'20024', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP500F8     ', 0, N'20047', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP500F9     ', 0, N'20046', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP500FA     ', 0, N'20045', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP500FB     ', 0, N'20044', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP600EY     ', 0, N'20058', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP600EZ     ', 0, N'20057', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP600F1     ', 0, N'20056', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP600F2     ', 0, N'20055', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP700EU     ', 0, N'20062', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP700EV     ', 0, N'20061', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP700EW     ', 0, N'20060', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP700EX     ', 0, N'20059', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP800BA     ', 0, N'20179', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP800BB     ', 0, N'20178', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP800BC     ', 0, N'20177', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP800BD     ', 0, N'20176', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP900BE     ', 0, N'20175', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP900BF     ', 0, N'20174', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP900BG     ', 0, N'20173', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRP900BH     ', 0, N'20172', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPA00BJ     ', 0, N'20171', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPA00BK     ', 0, N'20170', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPA00BL     ', 0, N'20169', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPA00BM     ', 0, N'20168', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPB00CY     ', 0, N'20124', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPB00CZ     ', 0, N'20123', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPB00D1     ', 0, N'20122', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPB00D2     ', 0, N'20121', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPC00D3     ', 0, N'20120', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPC00D4     ', 0, N'20119', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPC00D5     ', 0, N'20118', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPC00D6     ', 0, N'20117', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPD00D7     ', 0, N'20116', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPD00D8     ', 0, N'20115', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPD00D9     ', 0, N'20114', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPD00DA     ', 0, N'20113', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPE00FL     ', 0, N'20035', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPE00FM     ', 0, N'20034', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPE00FN     ', 0, N'20033', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFNRPE00FP     ', 0, N'20032', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRAG100AM     ', 0, N'20201', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRAG100AN     ', 0, N'20200', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRAG100AP     ', 0, N'20199', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRAG100AQ     ', 0, N'20198', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT100C9     ', 0, N'20147', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT100CA     ', 0, N'20146', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT100CB     ', 0, N'20145', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT100CC     ', 0, N'20144', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT100CD     ', 0, N'20143', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT200C4     ', 0, N'20152', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT200C5     ', 0, N'20151', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT200C6     ', 0, N'20150', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT200C7     ', 0, N'20149', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT200C8     ', 0, N'20148', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT300BY     ', 0, N'20157', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT300BZ     ', 0, N'20156', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT300C1     ', 0, N'20155', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT300C2     ', 0, N'20154', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT300C3     ', 0, N'20153', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT400DX     ', 0, N'20092', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT400DY     ', 0, N'20091', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT400DZ     ', 0, N'20090', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT400E1     ', 0, N'20089', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT400E2     ', 0, N'20088', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT500DS     ', 0, N'20097', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT500DT     ', 0, N'20096', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT500DU     ', 0, N'20095', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT500DV     ', 0, N'20094', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT500DW     ', 0, N'20093', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT600DM     ', 0, N'20102', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT600DN     ', 0, N'20101', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT600DP     ', 0, N'20100', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT600DQ     ', 0, N'20099', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT600DR     ', 0, N'20098', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT700E3     ', 0, N'20087', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT700E4     ', 0, N'20086', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT700E5     ', 0, N'20085', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT700E6     ', 0, N'20084', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT700E7     ', 0, N'20083', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT800E8     ', 0, N'20082', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT800E9     ', 0, N'20081', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT800EA     ', 0, N'20080', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT800EB     ', 0, N'20079', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT800EC     ', 0, N'20078', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT900ED     ', 0, N'20077', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT900EE     ', 0, N'20076', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT900EF     ', 0, N'20075', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT900EG     ', 0, N'20074', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWT900EH     ', 0, N'20073', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTA00EP     ', 0, N'20067', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTA00EQ     ', 0, N'20066', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTA00ER     ', 0, N'20065', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTA00ES     ', 0, N'20064', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTA00ET     ', 0, N'20063', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTB00BT     ', 0, N'20162', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTB00BU     ', 0, N'20161', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTB00BV     ', 0, N'20160', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTB00BW     ', 0, N'20159', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTB00BX     ', 0, N'20158', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTC00BN     ', 0, N'20167', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTC00BP     ', 0, N'20166', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTC00BQ     ', 0, N'20165', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTC00BR     ', 0, N'20164', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTC00BS     ', 0, N'20163', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTD00DG     ', 0, N'20107', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTD00DH     ', 0, N'20106', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTD00DJ     ', 0, N'20105', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTD00DK     ', 0, N'20104', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTD00DL     ', 0, N'20103', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTE00DB     ', 0, N'20112', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTE00DC     ', 0, N'20111', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTE00DD     ', 0, N'20110', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTE00DE     ', 0, N'20109', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTE00DF     ', 0, N'20108', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTF00EJ     ', 0, N'20072', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTF00EK     ', 0, N'20071', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTF00EL     ', 0, N'20070', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTF00EM     ', 0, N'20069', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFRWTF00EN     ', 0, N'20068', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AR     ', 0, N'20197', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AS     ', 0, N'20196', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AT     ', 0, N'20195', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AU     ', 0, N'20194', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AV     ', 0, N'20193', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AW     ', 0, N'20192', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AX     ', 0, N'20191', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AY     ', 0, N'20190', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR100AZ     ', 0, N'20189', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CE     ', 0, N'20142', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CF     ', 0, N'20141', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CG     ', 0, N'20140', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CH     ', 0, N'20139', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CJ     ', 0, N'20138', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CK     ', 0, N'20137', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CL     ', 0, N'20136', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CM     ', 0, N'20135', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR200CN     ', 0, N'20134', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CP     ', 0, N'20133', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CQ     ', 0, N'20132', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CR     ', 0, N'20131', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CS     ', 0, N'20130', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CT     ', 0, N'20129', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CU     ', 0, N'20128', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CV     ', 0, N'20127', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CW     ', 0, N'20126', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR300CX     ', 0, N'20125', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B1     ', 0, N'20188', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B2     ', 0, N'20187', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B3     ', 0, N'20186', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B4     ', 0, N'20185', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B5     ', 0, N'20184', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B6     ', 0, N'20183', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B7     ', 0, N'20182', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B8     ', 0, N'20181', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSOR400B9     ', 0, N'20180', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK300S1     ', 0, N'20289', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK300S2     ', 0, N'20288', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK300S3     ', 0, N'20287', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK300S4     ', 0, N'20286', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK300S5     ', 0, N'20283', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK300S6     ', 0, N'20282', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK300S7     ', 0, N'20281', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK300S8     ', 0, N'20280', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK600T6     ', 0, N'20276', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK600T7     ', 0, N'20275', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK600T8     ', 0, N'20302', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK600T9     ', 0, N'20301', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK600TA     ', 0, N'20300', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'MFSTK600TB     ', 0, N'20298', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'N01            ', 0, N'20300', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'N02            ', 0, N'20298', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'OHB200A01      ', 0, N'10049', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'OHB200A02      ', 0, N'10048', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'OHB200A03      ', 0, N'10011', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'OHB200A04      ', 0, N'10010', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'OHB200A05      ', 0, N'10009', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'T01            ', 0, N'20276', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[APORTSTATION] ([PORT_ID], [ADRTYPE], [ADR_ID], [LD_VH_TYPE], [ULD_VH_TYPE], [PRIORITY], [PORT_TYPE], [PORT_STATUS], [PORT_DIR], [PORT_SERVICE_STATUS]) VALUES (N'T02            ', 0, N'20275', 0, 0, 0, 0, 2, 0, 0)
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0001 ', 0, 48, 145, 10, 2126, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0002 ', 0, 128, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0003 ', 0, 141, 145, 10, 358, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0004 ', 0, 154, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0005 ', 0, 167, 145, 10, 523, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0006 ', 0, 186, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0007 ', 0, 199, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0008 ', 0, 212, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0009 ', 0, 225, 145, 10, 1193, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0010 ', 0, 270, 145, 10, 1331, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0011 ', 0, 320, 145, 10, 358, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0012 ', 0, 333, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0013 ', 0, 346, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0014 ', 0, 359, 145, 10, 520, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0015 ', 0, 378, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0016 ', 0, 391, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0017 ', 0, 404, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0018 ', 0, 417, 145, 10, 521, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0019 ', 0, 436, 145, 10, 359, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0020 ', 0, 449, 145, 10, 358, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0021 ', 0, 462, 145, 10, 361, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0022 ', 0, 475, 145, 10, 140, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0023 ', 0, 480, 145, 10, 378, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0024 ', 0, 494, 145, 10, 200, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0025 ', 0, 501, 145, 10, 319, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0026 ', 0, 513, 145, 10, 200, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0027 ', 0, 520, 145, 10, 378, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0028 ', 0, 534, 145, 10, 200, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0029 ', 0, 541, 145, 10, 319, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0030 ', 0, 553, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0031 ', 0, 566, 145, 10, 358, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0032 ', 0, 579, 145, 10, 523, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0033 ', 0, 598, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0034 ', 0, 611, 145, 10, 359, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0035 ', 0, 624, 145, 10, 359, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0036 ', 0, 637, 145, 10, 520, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0037 ', 0, 656, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0038 ', 0, 669, 145, 10, 359, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0039 ', 0, 682, 145, 10, 359, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0040 ', 0, 695, 145, 10, 525, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0041 ', 0, 714, 145, 10, 361, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0042 ', 0, 727, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0043 ', 0, 740, 145, 10, 359, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0044 ', 0, 753, 145, 10, 522, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0045 ', 0, 772, 145, 10, 358, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0046 ', 0, 785, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0047 ', 0, 798, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0048 ', 0, 811, 145, 10, 521, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0049 ', 0, 830, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0050 ', 0, 843, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0051 ', 0, 856, 145, 10, 361, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0052 ', 0, 869, 145, 10, 520, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0053 ', 0, 888, 145, 10, 358, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0054 ', 0, 901, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0055 ', 0, 914, 145, 10, 360, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0056 ', 0, 927, 145, 10, 695, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0057 ', 0, 953, 145, 10, 421, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0058 ', 0, 968, 145, 10, 419, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0059 ', 0, 983, 145, 10, 200, N'FF0080FF  ')
GO
INSERT [dbo].[ARAIL] ([RAIL_ID], [RAILTYPE], [LOCATIONX], [LOCATIONY], [WIDTH], [LENGTH], [COLOR]) VALUES (N'0060 ', 0, 990, 145, 10, 500, N'FF0080FF  ')
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'1  ', N'6  ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'103', N'179', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'103', N'370', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'103', N'54 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'103', N'56 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'103', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'104', N'179', 6, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'104', N'370', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'104', N'54 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'104', N'56 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'104', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'104', N'64 ', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'105', N'179', 6, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'105', N'370', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'105', N'54 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'105', N'56 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'105', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'105', N'60 ', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'106', N'179', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'106', N'370', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'106', N'54 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'106', N'56 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'107', N'179', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'107', N'54 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'107', N'66 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'108', N'179', 7, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'108', N'370', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'108', N'54 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'108', N'56 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'108', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'108', N'60 ', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'108', N'70 ', 6, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'109', N'179', 6, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'109', N'370', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'109', N'54 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'109', N'56 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'109', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'109', N'60 ', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'110', N'179', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'110', N'370', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'110', N'54 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'110', N'56 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'110', N'70 ', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'111', N'116', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'111', N'179', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'111', N'370', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'111', N'54 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'111', N'56 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'112', N'172', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'113', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'113', N'70 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'114', N'179', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'114', N'54 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'114', N'56 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'114', N'67 ', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'117', N'179', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'117', N'54 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'117', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'117', N'60 ', 6, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'117', N'62 ', 7, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'117', N'65 ', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'117', N'80 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'12 ', N'115', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'2  ', N'61 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'179', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'54 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'56 ', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'63 ', 7, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'72 ', 8, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'81 ', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'201', N'82 ', 6, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'205', N'172', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'208', N'370', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'208', N'890', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'209', N'179', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'210', N'54 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'211', N'179', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'211', N'54 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'211', N'56 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'212', N'893', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'213', N'115', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'213', N'179', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'31 ', N'81 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'31 ', N'82 ', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'31 ', N'83 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'51 ', N'179', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'51 ', N'54 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'51 ', N'56 ', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'51 ', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'51 ', N'63 ', 7, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'51 ', N'72 ', 8, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'51 ', N'81 ', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'51 ', N'82 ', 6, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'179', 3, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'54 ', 2, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'56 ', 4, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'58 ', 1, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'63 ', 7, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'68 ', 9, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'72 ', 8, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'81 ', 5, NULL, NULL)
GO
INSERT [dbo].[ARPTID] ([RPTID], [VID], [ORDER_NUM], [NAME], [UPD_TIME]) VALUES (N'52 ', N'82 ', 6, NULL, NULL)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01001', 1, 1, 1, 1, NULL, N'001', N'10000', N'10001', 2126, 60000, 0, 0, N'   ', 2, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'     ', 0, N'     ', 0, N'     ', 0, N'01002', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01002', 1, 1, 1, 1, NULL, N'001', N'10001', N'10002', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01001', 0, N'     ', 0, N'     ', 0, N'01003', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01003', 1, 1, 1, 1, NULL, N'001', N'10002', N'10003', 358, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01002', 0, N'     ', 0, N'     ', 0, N'01004', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01004', 1, 1, 1, 1, NULL, N'001', N'10003', N'10004', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01003', 0, N'     ', 0, N'     ', 0, N'01005', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01005', 1, 1, 1, 1, NULL, N'001', N'10004', N'10005', 523, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01004', 0, N'     ', 0, N'     ', 0, N'01006', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01006', 1, 1, 1, 1, NULL, N'001', N'10005', N'10006', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01005', 0, N'     ', 0, N'     ', 0, N'01007', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01007', 1, 1, 1, 1, NULL, N'001', N'10006', N'10007', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01006', 0, N'     ', 0, N'     ', 0, N'01008', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01008', 1, 1, 1, 1, NULL, N'001', N'10007', N'10008', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01007', 0, N'     ', 0, N'     ', 0, N'01009', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01009', 1, 1, 1, 1, NULL, N'001', N'10008', N'10009', 1193, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01008', 0, N'     ', 0, N'     ', 0, N'01010', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01010', 1, 1, 1, 1, NULL, N'001', N'10009', N'10010', 1331, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01009', 0, N'     ', 0, N'     ', 0, N'01011', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01011', 1, 1, 1, 1, NULL, N'001', N'10010', N'10011', 358, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01010', 0, N'     ', 0, N'     ', 0, N'01012', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01012', 1, 1, 1, 1, NULL, N'001', N'10011', N'10012', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01011', 0, N'     ', 0, N'     ', 0, N'01013', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01013', 1, 1, 1, 1, NULL, N'001', N'10012', N'10013', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01012', 0, N'     ', 0, N'     ', 0, N'01014', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01014', 1, 1, 1, 1, NULL, N'001', N'10013', N'10014', 520, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01013', 0, N'     ', 0, N'     ', 0, N'01015', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01015', 1, 1, 1, 1, NULL, N'001', N'10014', N'10015', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01014', 0, N'     ', 0, N'     ', 0, N'01016', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01016', 1, 1, 1, 1, NULL, N'001', N'10015', N'10016', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01015', 0, N'     ', 0, N'     ', 0, N'01017', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01017', 1, 1, 1, 1, NULL, N'001', N'10016', N'10017', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01016', 0, N'     ', 0, N'     ', 0, N'01018', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01018', 1, 1, 1, 1, NULL, N'001', N'10017', N'10018', 521, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01017', 0, N'     ', 0, N'     ', 0, N'01019', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01019', 1, 1, 1, 1, NULL, N'001', N'10018', N'10019', 359, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01018', 0, N'     ', 0, N'     ', 0, N'01020', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01020', 1, 1, 1, 1, NULL, N'001', N'10019', N'10020', 358, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01019', 0, N'     ', 0, N'     ', 0, N'01021', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01021', 1, 1, 1, 1, NULL, N'001', N'10020', N'10021', 361, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01020', 0, N'     ', 0, N'     ', 0, N'01022', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01022', 1, 1, 1, 1, NULL, N'001', N'10021', N'10022', 523, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01021', 0, N'     ', 0, N'     ', 0, N'01023', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01023', 1, 1, 1, 1, NULL, N'001', N'10022', N'10023', 358, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01022', 0, N'     ', 0, N'     ', 0, N'01024', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01024', 1, 1, 1, 1, NULL, N'001', N'10023', N'10024', 359, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01023', 0, N'     ', 0, N'     ', 0, N'01025', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01025', 1, 1, 1, 1, NULL, N'001', N'10024', N'10025', 361, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01024', 0, N'     ', 0, N'     ', 0, N'01026', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01026', 1, 1, 1, 1, NULL, N'001', N'10025', N'10026', 140, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01025', 0, N'     ', 0, N'     ', 0, N'01027', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01027', 1, 1, 1, 1, NULL, N'001', N'10026', N'10027', 378, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01026', 0, N'     ', 0, N'     ', 0, N'01028', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01028', 1, 1, 1, 1, NULL, N'001', N'10027', N'10028', 42, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01027', 0, N'     ', 0, N'     ', 0, N'01029', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01029', 1, 1, 1, 1, NULL, N'001', N'10028', N'10029', 319, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01028', 0, N'     ', 0, N'     ', 0, N'01030', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01030', 1, 1, 1, 1, NULL, N'001', N'10029', N'10030', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01029', 0, N'     ', 0, N'     ', 0, N'01031', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01031', 1, 1, 1, 1, NULL, N'001', N'10030', N'10031', 358, 60000, 0, 0, N'   ', 2, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01030', 0, N'     ', 0, N'     ', 0, N'01032', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 1, NULL, 1, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01032', 1, 1, 1, 1, NULL, N'001', N'10031', N'10032', 523, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01031', 0, N'     ', 0, N'     ', 0, N'01033', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 2, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01033', 1, 1, 1, 1, NULL, N'001', N'10032', N'10033', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01032', 0, N'     ', 0, N'     ', 0, N'01034', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 3, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01034', 1, 1, 1, 1, NULL, N'001', N'10033', N'10034', 359, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01033', 0, N'     ', 0, N'     ', 0, N'01035', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 4, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01035', 1, 1, 1, 1, NULL, N'001', N'10034', N'10035', 359, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01034', 0, N'     ', 0, N'     ', 0, N'01036', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 5, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01036', 1, 1, 1, 1, NULL, N'001', N'10035', N'10036', 520, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01035', 0, N'     ', 0, N'     ', 0, N'01037', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 6, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01037', 1, 1, 1, 1, NULL, N'001', N'10036', N'10037', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01036', 0, N'     ', 0, N'     ', 0, N'01038', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 7, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01038', 1, 1, 1, 1, NULL, N'001', N'10037', N'10038', 359, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01037', 0, N'     ', 0, N'     ', 0, N'01039', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 8, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01039', 1, 1, 1, 1, NULL, N'001', N'10038', N'10039', 359, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01038', 0, N'     ', 0, N'     ', 0, N'01040', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 9, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01040', 1, 1, 1, 1, NULL, N'001', N'10039', N'10040', 525, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01039', 0, N'     ', 0, N'     ', 0, N'01041', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 10, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01041', 1, 1, 1, 1, NULL, N'001', N'10040', N'10041', 361, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01040', 0, N'     ', 0, N'     ', 0, N'01042', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 11, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01042', 1, 1, 1, 1, NULL, N'001', N'10041', N'10042', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01041', 0, N'     ', 0, N'     ', 0, N'01043', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 12, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01043', 1, 1, 1, 1, NULL, N'001', N'10042', N'10043', 359, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01042', 0, N'     ', 0, N'     ', 0, N'01044', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 13, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01044', 1, 1, 1, 1, NULL, N'001', N'10043', N'10044', 522, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01043', 0, N'     ', 0, N'     ', 0, N'01045', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 14, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01045', 1, 1, 1, 1, NULL, N'001', N'10044', N'10045', 358, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01044', 0, N'     ', 0, N'     ', 0, N'01046', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 15, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01046', 1, 1, 1, 1, NULL, N'001', N'10045', N'10046', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01045', 0, N'     ', 0, N'     ', 0, N'01047', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 16, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01047', 1, 1, 1, 1, NULL, N'001', N'10046', N'10047', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01046', 0, N'     ', 0, N'     ', 0, N'01048', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 17, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01048', 1, 1, 1, 1, NULL, N'001', N'10047', N'10048', 521, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01047', 0, N'     ', 0, N'     ', 0, N'01049', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 18, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01049', 1, 1, 1, 1, NULL, N'001', N'10048', N'10049', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01048', 0, N'     ', 0, N'     ', 0, N'01050', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 19, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01050', 1, 1, 1, 1, NULL, N'001', N'10049', N'10050', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01049', 0, N'     ', 0, N'     ', 0, N'01051', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 20, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01051', 1, 1, 1, 1, NULL, N'001', N'10050', N'10051', 361, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01050', 0, N'     ', 0, N'     ', 0, N'01052', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 21, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01052', 1, 1, 1, 1, NULL, N'001', N'10051', N'10052', 520, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01051', 0, N'     ', 0, N'     ', 0, N'01053', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 22, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01053', 1, 1, 1, 1, NULL, N'001', N'10052', N'10053', 358, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01052', 0, N'     ', 0, N'     ', 0, N'01054', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 23, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01054', 1, 1, 1, 1, NULL, N'001', N'10053', N'10054', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01053', 0, N'     ', 0, N'     ', 0, N'01055', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 24, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01055', 1, 1, 1, 1, NULL, N'001', N'10054', N'10055', 360, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01054', 0, N'     ', 0, N'     ', 0, N'01056', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 25, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01056', 1, 1, 1, 1, NULL, N'001', N'10055', N'10056', 695, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01055', 0, N'     ', 0, N'     ', 0, N'01057', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 26, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01057', 1, 1, 1, 1, NULL, N'001', N'10056', N'10057', 421, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01056', 0, N'     ', 0, N'     ', 0, N'01058', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 27, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01058', 1, 1, 1, 1, NULL, N'001', N'10057', N'10058', 419, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01057', 0, N'     ', 0, N'     ', 0, N'01059', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 28, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01059', 1, 1, 1, 1, NULL, N'001', N'10058', N'10059', 155, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01058', 0, N'     ', 0, N'     ', 0, N'01060', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 29, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASECTION] ([SEC_ID], [SEC_ORDER_NUM], [SEG_ORDER_NUM], [DIRC_DRIV], [DIRC_GUID], [AREA_SECSOR], [SEG_NUM], [FROM_ADR_ID], [TO_ADR_ID], [SEC_DIS], [SEC_SPD], [DIS_FROM_ORIGIN], [CDOG_1], [CHG_SEG_NUM_1], [CDOG_2], [CHG_SEG_NUM_2], [PRE_BLO_REQ], [SEC_TYPE], [SEC_DIR], [PADDING], [ENB_CHG_G_AREA], [PRE_DIV], [PRE_ADD_REPR], [OBS_SENSOR], [LAST_TECH_TIME], [SUB_VER], [ADD_TIME], [ADD_USER], [UPD_TIME], [UPD_USER], [START_BC1], [END_BC1], [START_BC2], [END_BC2], [START_BC3], [END_BC3], [ADR1_CHG_SEC_ID_1], [ADR1_CHG_SEC_COST_1], [ADR1_CHG_SEC_ID_2], [ADR1_CHG_SEC_COST_2], [ADR1_CHG_SEC_ID_3], [ADR1_CHG_SEC_COST_3], [ADR2_CHG_SEC_ID_1], [ADR2_CHG_SEC_COST_1], [ADR2_CHG_SEC_ID_2], [ADR2_CHG_SEC_COST_2], [ADR2_CHG_SEC_ID_3], [ADR2_CHG_SEC_COST_3], [SEC_COST_From2To], [SEC_COST_To2From], [ISBANEND_From2To], [ISBANEND_To2From], [STATUS], [NOTE], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_CHARGE], [DISABLE_FLAG_SYSTEM]) VALUES (N'01060', 1, 1, 1, 1, NULL, N'001', N'10059', N'10060', 500, 60000, 0, 0, N'   ', 0, N'   ', 0, 0, 1, 0, 0, 0, 0, 0, NULL, N'0   ', NULL, N'          ', NULL, N'          ', 0, 0, 0, 0, 0, 0, N'01059', 0, N'     ', 0, N'     ', 0, N'     ', 0, N'     ', 0, N'     ', 0, 0, 0, 0, 0, 30, NULL, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASEGMENT] ([SEG_NUM], [STATUS], [SEG_TYPE], [SPECIAL_MARK], [RESERVE_FIELD], [NOTE], [DIR], [PRE_DISABLE_FLAG], [PRE_DISABLE_TIME], [DISABLE_TIME], [DISABLE_FLAG_USER], [DISABLE_FLAG_SAFETY], [DISABLE_FLAG_HID], [DISABLE_FLAG_SYSTEM]) VALUES (N'001       ', 1, 1, NULL, NULL, NULL, 1, 0, NULL, NULL, 0, 0, 0, 0)
GO
INSERT [dbo].[ASEQUENCE] ([SEQ_NAME], [NXT_VAL]) VALUES (N'CMD_MANUAL_SEQ ', 8866)
GO
INSERT [dbo].[AVEHICLE] ([VEHICLE_ID], [VEHICLE_TYPE], [CUR_ADR_ID], [CUR_SEC_ID], [SEC_ENTRY_TIME], [ACC_SEC_DIST], [MODE_STATUS], [ACT_STATUS], [MCS_CMD], [OHTC_CMD], [BLOCK_PAUSE], [CMD_PAUSE], [OBS_PAUSE], [HID_PAUSE], [ERROR], [EARTHQUAKE_PAUSE], [SAFETY_DOOR_PAUSE], [OHXC_OBS_PAUSE], [OHXC_BLOCK_PAUSE], [OBS_DIST], [HAS_CST], [CST_ID], [UPD_TIME], [VEHICLE_ACC_DIST], [MANT_ACC_DIST], [MANT_DATE], [GRIP_COUNT], [GRIP_MANT_COUNT], [GRIP_MANT_DATE], [NODE_ADR], [IS_PARKING], [PARK_TIME], [PARK_ADR_ID], [IS_CYCLING], [CYCLERUN_TIME], [CYCLERUN_ID], [IS_INSTALLED], [INSTALLED_TIME], [REMOVED_TIME], [BOX_ID], [LOT_ID], [HAS_BOX]) VALUES (N'B7_OHBLINE2_CR1                 ', 0, NULL, NULL, NULL, 0, 4, 0, N'                                                                ', N'                                                                ', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, N'                                                                ', CAST(N'2021-02-05T16:22:33.3928362' AS DateTime2), 0, 0, NULL, 0, 0, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, N'08SA0109                                                        ', NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'B7_OHBLINE2_CR1                 ', NULL, N'                                                                ', N'                                                                ', CAST(N'2021-02-05T16:22:28.600' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'101901                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'CR1                             ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'MTL                             ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHB100CR1                       ', NULL, N'                                                                ', N'                                                                ', CAST(N'2020-03-02T23:36:29.330' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'                                                                ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHB200CR1                       ', NULL, N'                                                                ', N'                                                                ', CAST(N'2020-03-11T16:52:02.990' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'105201                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHB300CR1                       ', NULL, N'                                                                ', N'                                                                ', CAST(N'2020-03-13T17:42:45.290' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'100901                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx01                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-11-22T13:56:48.033' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'                                                                ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx02                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-11-22T13:53:02.800' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'                                                                ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx03                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-11-22T13:36:38.377' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'MFSOR100AU                                                      ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx04                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-09-18T13:40:08.093' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'MFSTK600T9                                                      ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx05                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-09-18T13:33:43.710' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'MFSTK600TA                                                      ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx06                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'P20059                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx07                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'P20006                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx08                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-06-26T11:11:01.247' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'MFSTK600T7                                                      ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx09                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-09-06T12:25:17.127' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'MFSTK600T9                                                      ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx10                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'P20074                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx11                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-06-26T11:36:31.987' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'MFSTK600T9                                                      ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx12                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'P20215                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx13                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'P20110                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx14                           ', NULL, N'                                                                ', N'                                                                ', CAST(N'2019-09-18T13:41:58.707' AS DateTime), N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'MFSTK600TA                                                      ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx15                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx16                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx17                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx18                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx19                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx20                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx21                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx22                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'OHx23                           ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'P1                              ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'P20206                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'P2                              ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'P20287                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'P4                              ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 0, 0, 0, NULL, NULL, NULL, NULL, N'P20205                                                          ', 0)
GO
INSERT [dbo].[AVIDINFO] ([EQ_ID], [MCS_CARRIER_ID], [CARRIER_ID], [CARRIER_LOC], [CARRIER_INSTALLED_TIME], [COMMAND_ID], [SOURCEPORT], [DESTPORT], [PRIORITY], [RESULT_CODE], [VEHICLE_STATE], [COMMAND_TYPE], [ALARM_ID], [ALARM_TEXT], [UNIT_ID], [PORT_ID], [REPLACE]) VALUES (N'Y1                              ', NULL, N'                                                                ', N'                                                                ', NULL, N'                                                                ', N'                                                                ', N'                                                                ', 10, 0, 0, NULL, NULL, NULL, NULL, N'P20073                                                          ', 0)
GO
INSERT [dbo].[AZONE] ([ZONE_ID], [LINE_ID], [LOT_ID]) VALUES (N'VH_LINE        ', N'VH_LINE        ', NULL)
GO
INSERT [dbo].[BCSTAT] ([BC_ID], [CLOSE_MODE], [RUN_TIMESTAMP]) VALUES (N'Taichung  ', N'0', N'2018051716043874')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-17T13:20:49.7716360' AS DateTime2), CAST(N'2019-10-17T13:20:49.6758901' AS DateTime2), CAST(N'2019-10-17T13:20:50.3261537' AS DateTime2), CAST(N'2019-10-17T13:20:52.6609515' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-17T15:37:29.4725155' AS DateTime2), CAST(N'2019-10-17T15:37:29.3638038' AS DateTime2), CAST(N'2019-10-17T15:37:29.6869393' AS DateTime2), CAST(N'2019-10-17T15:37:32.4914421' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-18T10:58:09.9512938' AS DateTime2), CAST(N'2019-10-18T10:58:09.8585372' AS DateTime2), CAST(N'2019-10-18T10:58:10.2365265' AS DateTime2), CAST(N'2019-10-18T10:58:12.7597804' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-18T11:19:28.0272956' AS DateTime2), CAST(N'2019-10-18T11:19:27.7989065' AS DateTime2), CAST(N'2019-10-18T11:19:29.5233047' AS DateTime2), CAST(N'2019-10-18T11:19:47.4575199' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-22T17:33:00.4104459' AS DateTime2), CAST(N'2019-10-22T17:32:59.7423425' AS DateTime2), CAST(N'2019-10-22T17:33:00.8895811' AS DateTime2), CAST(N'2019-10-22T17:33:03.1572936' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-22T20:41:54.0083151' AS DateTime2), CAST(N'2019-10-22T20:41:53.4518037' AS DateTime2), CAST(N'2019-10-22T20:41:54.2002668' AS DateTime2), CAST(N'2019-10-22T20:41:57.8890193' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-24T16:50:47.2482109' AS DateTime2), CAST(N'2019-10-24T16:50:47.1038758' AS DateTime2), CAST(N'2019-10-24T16:50:47.5284500' AS DateTime2), CAST(N'2019-10-24T16:50:50.7916564' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-24T18:05:17.5269978' AS DateTime2), CAST(N'2019-10-24T18:05:17.4377196' AS DateTime2), CAST(N'2019-10-24T18:05:17.8627892' AS DateTime2), CAST(N'2019-10-24T18:05:20.5337444' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-25T11:51:57.8075623' AS DateTime2), CAST(N'2019-10-25T11:51:57.7656738' AS DateTime2), CAST(N'2019-10-25T11:51:58.0678730' AS DateTime2), CAST(N'2019-10-25T11:52:00.6689920' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-30T14:11:06.5480362' AS DateTime2), CAST(N'2019-10-30T14:11:06.1680518' AS DateTime2), CAST(N'2019-10-30T14:11:07.7508183' AS DateTime2), CAST(N'2019-10-30T14:11:10.2202134' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-30T16:30:28.9239579' AS DateTime2), CAST(N'2019-10-30T16:30:28.8521507' AS DateTime2), CAST(N'2019-10-30T16:30:29.1294094' AS DateTime2), CAST(N'2019-10-30T16:30:32.6200749' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-30T17:24:47.5715977' AS DateTime2), CAST(N'2019-10-30T17:24:47.4977950' AS DateTime2), CAST(N'2019-10-30T17:24:48.7201179' AS DateTime2), CAST(N'2019-10-30T17:24:50.6533035' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-10-31T10:22:13.1801986' AS DateTime2), CAST(N'2019-10-31T10:22:13.1293336' AS DateTime2), CAST(N'2019-10-31T10:22:15.6585697' AS DateTime2), CAST(N'2019-10-31T10:22:18.0192585' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-01T14:29:32.7959745' AS DateTime2), CAST(N'2019-11-01T14:29:32.7241676' AS DateTime2), CAST(N'2019-11-01T14:29:33.2278204' AS DateTime2), CAST(N'2019-11-01T14:29:37.3458095' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-04T09:22:59.7424365' AS DateTime2), CAST(N'2019-11-04T09:22:59.6865847' AS DateTime2), CAST(N'2019-11-04T09:22:59.8960251' AS DateTime2), CAST(N'2019-11-04T09:23:02.4422260' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-05T09:51:04.7032232' AS DateTime2), CAST(N'2019-11-05T09:51:04.6344083' AS DateTime2), CAST(N'2019-11-05T09:51:04.8498311' AS DateTime2), CAST(N'2019-11-05T09:51:08.3555016' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-21T10:39:51.8663422' AS DateTime2), CAST(N'2019-11-21T10:39:51.8433894' AS DateTime2), CAST(N'2019-11-21T10:39:51.9371125' AS DateTime2), CAST(N'2019-11-21T10:39:54.4589798' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-22T08:56:54.3471279' AS DateTime2), CAST(N'2019-11-22T08:56:54.3312310' AS DateTime2), CAST(N'2019-11-22T08:56:54.4049730' AS DateTime2), CAST(N'2019-11-22T08:56:56.9161057' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-22T09:49:34.0632885' AS DateTime2), CAST(N'2019-11-22T09:49:34.0473618' AS DateTime2), CAST(N'2019-11-22T09:49:34.1360919' AS DateTime2), CAST(N'2019-11-22T09:49:36.6528860' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-22T13:33:00.1264664' AS DateTime2), CAST(N'2019-11-22T13:33:00.1015323' AS DateTime2), CAST(N'2019-11-22T13:33:00.2531276' AS DateTime2), CAST(N'2019-11-22T13:33:02.6846978' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-25T14:54:13.8467426' AS DateTime2), CAST(N'2019-11-25T14:54:13.7854810' AS DateTime2), CAST(N'2019-11-25T14:54:13.8876339' AS DateTime2), CAST(N'2019-11-25T14:54:16.3988369' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-25T15:37:49.9987712' AS DateTime2), CAST(N'2019-11-25T15:37:49.9698486' AS DateTime2), CAST(N'2019-11-25T15:37:50.0526224' AS DateTime2), CAST(N'2019-11-25T15:37:52.5768539' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-25T16:41:14.4537858' AS DateTime2), CAST(N'2019-11-25T16:41:14.4338387' AS DateTime2), CAST(N'2019-11-25T16:41:14.4976696' AS DateTime2), CAST(N'2019-11-25T16:41:17.0159675' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-25T17:20:30.5252885' AS DateTime2), CAST(N'2019-11-25T17:20:30.5023496' AS DateTime2), CAST(N'2019-11-25T17:20:30.5831399' AS DateTime2), CAST(N'2019-11-25T17:20:33.1186871' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-25T17:45:04.3626128' AS DateTime2), CAST(N'2019-11-25T17:45:04.3486127' AS DateTime2), CAST(N'2019-11-25T17:45:04.4014718' AS DateTime2), CAST(N'2019-11-25T17:45:06.9224997' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx01     ', CAST(N'2019-11-26T10:19:43.1631174' AS DateTime2), CAST(N'2019-11-26T10:19:43.1461620' AS DateTime2), CAST(N'2019-11-26T10:19:43.2199648' AS DateTime2), CAST(N'2019-11-26T10:19:45.7321728' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02701', N'OHx01     ', CAST(N'2019-10-22T20:41:56.9510784' AS DateTime2), CAST(N'2019-10-22T20:41:56.8548543' AS DateTime2), CAST(N'2019-10-22T20:41:58.0650922' AS DateTime2), CAST(N'2019-10-22T20:42:03.1694196' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02701', N'OHx01     ', CAST(N'2019-11-22T09:49:36.5990625' AS DateTime2), CAST(N'2019-11-22T09:49:36.5950839' AS DateTime2), CAST(N'2019-11-22T09:49:36.6658522' AS DateTime2), CAST(N'2019-11-22T09:49:40.1627398' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx02     ', CAST(N'2019-10-31T11:32:00.5357169' AS DateTime2), CAST(N'2019-10-31T11:32:00.0305542' AS DateTime2), CAST(N'2019-10-31T11:32:00.9954864' AS DateTime2), CAST(N'2019-10-31T11:32:04.4133481' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx02     ', CAST(N'2019-11-01T14:37:55.8800527' AS DateTime2), CAST(N'2019-11-01T14:37:55.7912906' AS DateTime2), CAST(N'2019-11-01T14:37:56.0426180' AS DateTime2), CAST(N'2019-11-01T14:37:58.7174660' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx02     ', CAST(N'2019-11-04T09:23:22.6244942' AS DateTime2), CAST(N'2019-11-04T09:23:22.6065409' AS DateTime2), CAST(N'2019-11-04T09:23:22.7691077' AS DateTime2), CAST(N'2019-11-04T09:23:25.4100440' AS DateTime2), N'4')
GO
INSERT [dbo].[BLOCKZONEQUEUE] ([ENTRY_SEC_ID], [CAR_ID], [REQ_TIME], [BLOCK_TIME], [THROU_TIME], [RELEASE_TIME], [STATUS]) VALUES (N'02628', N'OHx02     ', CAST(N'2019-11-05T09:51:29.7727438' AS DateTime2), CAST(N'2019-11-05T09:51:29.7468138' AS DateTime2), CAST(N'2019-11-05T09:51:29.8305903' AS DateTime2), CAST(N'2019-11-05T09:51:33.3471960' AS DateTime2), N'4')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0583', N'08SA0062', N'104201', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0191SFJB050', NULL, NULL, N'21/02/04 21:35:17', N'21/02/04 21:36:05', NULL, NULL, N'21/02/04 21:36:05', N'0')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0805', N'08SA0109', N'101901', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'1HGQME5', NULL, NULL, N'21/02/05 16:21:23', N'21/02/05 16:22:28', NULL, NULL, N'21/02/05 16:22:28', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0648', N'08SA0121', N'102001', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'1HGQMDY', NULL, NULL, N'21/02/05 16:20:38', N'21/02/05 16:21:33', NULL, NULL, N'21/02/05 16:21:33', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0603', N'08SA0185', N'104501', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'1HGQMAA', NULL, NULL, N'21/02/05 04:30:07', N'21/02/05 04:32:00', NULL, NULL, N'21/02/05 04:32:00', N'0')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'', N'08SA0193', N'101501', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0', NULL, NULL, N'21/02/05 06:38:14', N'21/02/05 06:38:55', NULL, NULL, N'21/02/05 06:38:55', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0985', N'08SA0216', N'104401', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'1EBQMU6', NULL, NULL, N'21/02/05 04:28:19', N'21/02/05 04:29:36', NULL, NULL, N'21/02/05 04:29:36', N'0')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'', N'08SA0283', N'101701', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0', NULL, NULL, N'21/02/05 05:39:24', N'21/02/05 05:40:05', NULL, NULL, N'21/02/05 05:40:05', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0210', N'08SA0308', N'102101', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0121SUNB002', NULL, NULL, N'21/02/05 15:58:54', N'21/02/05 15:59:34', NULL, NULL, N'21/02/05 15:59:34', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0508', N'08SA0379', N'102301', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'9491SN5B004', NULL, NULL, N'21/02/04 17:01:36', N'21/02/04 17:02:24', NULL, NULL, N'21/02/04 17:02:24', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0892', N'08SA0404', N'102201', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0191SFJB048', NULL, NULL, N'21/02/04 21:02:12', N'21/02/04 21:03:07', NULL, NULL, N'21/02/04 21:03:07', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'', N'08SA0429', N'101801', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0', NULL, NULL, N'21/02/05 02:23:47', N'21/02/05 02:26:19', NULL, NULL, N'21/02/05 02:26:19', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0060', N'08SA0444', N'102501', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0121SUNB004', NULL, NULL, N'21/02/05 13:33:03', N'21/02/05 13:33:44', NULL, NULL, N'21/02/05 13:33:44', N'5')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'08CU0894', N'08SA0474', N'103801', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0111SSPB001', NULL, NULL, N'21/02/04 18:09:04', N'21/02/04 18:09:55', NULL, NULL, N'21/02/04 18:09:55', N'0')
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'', N'08SA0503', N'101101', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'', NULL, NULL, N'21/02/04 19:27:55', N'21/02/04 19:28:50', NULL, NULL, N'21/02/04 19:28:50', NULL)
GO
INSERT [dbo].[CassetteData] ([StockerID], [CSTID], [BOXID], [Carrier_LOC], [Stage], [CSTState], [LotID], [EmptyCST], [CSTType], [CSTInDT], [StoreDT], [WaitOutOPDT], [WaitOutLPDT], [TrnDT], [ReadStatus]) VALUES (N'1', N'', N'08SA0529', N'102401', CAST(1 AS Numeric(2, 0)), CAST(3 AS Numeric(1, 0)), N'0', NULL, NULL, N'21/02/05 13:40:59', N'21/02/05 13:41:34', NULL, NULL, N'21/02/05 13:41:34', N'5')
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'100101', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10001', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'100201', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10002', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'100301', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10003', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'100401', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10004', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'100501', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10005', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'100601', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10006', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'100701', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10007', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'100801', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10008', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101001', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10010', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101101', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10011', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101201', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10012', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101301', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10013', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101401', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10014', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101501', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10015', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101601', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10016', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101701', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10017', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101801', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10018', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'101901', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10019', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'102001', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10020', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'102101', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10021', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'102201', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10022', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'102301', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10023', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'102401', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10024', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'102501', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10025', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'103601', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10036', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'103701', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10037', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'103801', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10038', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'103901', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10039', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104001', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10040', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104101', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10041', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104201', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10042', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104301', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10043', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104401', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10044', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104501', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10045', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104601', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10046', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104701', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10047', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104801', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10048', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'104901', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10049', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105001', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10050', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105101', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10051', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105201', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10052', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105301', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10053', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105401', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10054', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105501', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10055', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105601', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10056', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105701', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10057', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105801', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10058', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'105901', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'SHELF', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), NULL, NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10059', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_A01', N'B7_OHBLINE2', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), N'AGV', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE1', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10026', N'B7_OHBLINE2_ST02', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_A02', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), N'AGV', NULL, NULL, CAST(0 AS Numeric(2, 0)), 1, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE1', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10028', N'B7_OHBLINE2_ST02', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_A03', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), N'AGV', NULL, NULL, CAST(1 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE1', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10056', N'B7_OHBLINE2_ST01', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_A04', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), N'AGV', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE2', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10057', N'B7_OHBLINE2_ST01', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_A05', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), N'AGV', NULL, NULL, CAST(0 AS Numeric(2, 0)), 1, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE1', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10058', N'B7_OHBLINE2_ST01', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_ST01', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'AGVZONE', NULL, NULL, CAST(1 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE1', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10026', N'AGVZONE', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_ST02', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'AGVZONE', NULL, NULL, CAST(1 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(0 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE1', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10026', N'AGVZONE', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_T01', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'NTB', NULL, NULL, CAST(1 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(100 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE2', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10009', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_T02', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'STK', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(100 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE2', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10032', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLINE2_T03', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'STK', NULL, NULL, CAST(1 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(100 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE2', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10034', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLOOP_T03', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'OHCV', NULL, NULL, CAST(0 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(100 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE1', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10059', N'1', 0)
GO
INSERT [dbo].[PortDef] ([StockerID], [PLCPortID], [OHBName], [State], [Stage], [AGVState], [UnitType], [HostEQPortID], [ShelfID], [PortType], [PortTypeDef], [PortLocationType], [PortTypeIndex], [SourceWeighted], [DestWeighted], [Direction], [Color], [TimeOutForAutoUD], [TimeOutForAutoInZone], [AlternateToZone], [Vehicles], [Floor], [IgnoreModeChange], [ReportMCSFlag], [ReportStage], [NetHStnNo], [AreaSensorStnNo], [Presenton_InsCST], [Presentoff_DelCST], [ToEQ], [TrnDT], [AlarmType], [ADR_ID], [ZoneName], [PRIORITY]) VALUES (NULL, N'B7_OHBLOOP_T04', N'B7_OHBLINE2', CAST(2 AS Numeric(2, 0)), CAST(5 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'OHCV', NULL, NULL, CAST(1 AS Numeric(2, 0)), 0, CAST(2 AS Numeric(2, 0)), NULL, CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(1, 0)), NULL, CAST(100 AS Numeric(6, 0)), N'B7_OHBLINE2-ZONE2', NULL, CAST(1 AS Numeric(1, 0)), CAST(0 AS Numeric(1, 0)), N'N', N'Y', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), N'N', N'N', NULL, NULL, CAST(3 AS Numeric(2, 0)), N'10059', N'1', 0)
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'100101', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10001')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'100201', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10002')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'100301', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10003')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'100401', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10004')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'100501', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10005')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'100601', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10006')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'100701', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10007')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'100801', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10008')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101001', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10010')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101101', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10011')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101201', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10012')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101301', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10013')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101401', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10014')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101501', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10015')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101601', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10016')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101701', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10017')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101801', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10018')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'101901', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10019')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'102001', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10020')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'102101', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10021')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'102201', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10022')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'102301', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10023')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'102401', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10024')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'102501', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE1', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10025')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'103601', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10036')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'103701', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10037')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'103801', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10038')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'103901', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10039')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104001', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10040')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104101', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10041')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104201', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10042')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104301', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10043')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104401', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10044')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104501', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'S', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10045')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104601', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10046')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104701', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10047')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104801', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10048')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'104901', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10049')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105001', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10050')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105101', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10051')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105201', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10052')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105301', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10053')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105401', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10054')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105501', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10055')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105601', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10056')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105701', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10057')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105801', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10058')
GO
INSERT [dbo].[ShelfDef] ([StockerID], [ShelfID], [Stage], [Bank_X], [Bay_Y], [Level_Z], [LocateCraneNo], [ShelfType], [ShelfState], [ZoneID], [Enable], [OldEnableSts], [EmptyBlockFlag], [HoldState], [BCRReadFlag], [TransferTimes], [ChargeLoc], [SelectPriority], [Remark], [TrnDT], [HandoffDirection], [ADR_ID]) VALUES (N'1', N'105901', CAST(2 AS Numeric(2, 0)), N'2', N'2', N'2', CAST(2 AS Numeric(2, 0)), CAST(2 AS Numeric(2, 0)), N'N', N'B7_OHBLINE2-ZONE2', N'Y', N'1', N'1', CAST(1 AS Numeric(1, 0)), N'1', CAST(11 AS Numeric(10, 0)), N'1', CAST(1 AS Numeric(2, 0)), N'1', N'1', NULL, N'10059')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_ACCOUNT_MANAGEMENT                                     ', N'User Account Management                                                         ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_ADVANCED_SETTINGS                                      ', N'Advanced Settings                                                               ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_CASSETTE_MAINTENANCE                                   ', N'Cassette Maintenance                                                            ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_CLOSE_SYSTEM                                           ', N'System Shutdown                                                                 ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_COMMUNICATION_MAINTENANCE                              ', N'Communication maintenance                                                       ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_DEBUG                                                  ', N'Debug                                                                           ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_LOGIN                                                  ', N'User Login                                                                      ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_MTS_MTL_MAINTENANCE                                    ', N'MTS/MTL Maintenance                                                             ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_MULTI_TRANFER_COMMAND                                  ', N'Multi Tranfer Command                                                           ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_OHT_CONTROL                                            ', N'OHT Control                                                                     ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_PORT_CONTROL                                           ', N'Port Control                                                                    ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_PORT_MAINTENANCE                                       ', N'Port Maintenance                                                                ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_SYSTEM_CONCROL_MODE                                    ', N'System Control                                                                  ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_TEST_RUN                                               ', N'Test Run                                                                        ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_TRANSFER_MANAGEMENT                                    ', N'Transfer Management                                                             ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_VEHICLE_MANAGEMENT                                     ', N'Vehicle Management                                                              ')
GO
INSERT [dbo].[UASFNC] ([FUNC_CODE], [FUNC_NAME]) VALUES (N'FUNC_ZONE_SHELF_MAINTENANCE                                 ', N'Zone/Shelf Maintenance                                                          ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_ACCOUNT_MANAGEMENT                                     ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_CASSETTE_MAINTENANCE                                   ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_CLOSE_SYSTEM                                           ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_COMMUNICATION_MAINTENANCE                              ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_DEBUG                                                  ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_LOGIN                                                  ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_MULTI_TRANFER_COMMAND                                  ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_OHT_CONTROL                                            ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_PORT_CONTROL                                           ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_PORT_MAINTENANCE                                       ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_SYSTEM_CONCROL_MODE                                    ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_TEST_RUN                                               ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_TRANSFER_MANAGEMENT                                    ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_VEHICLE_MANAGEMENT                                     ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ADMIN               ', N'FUNC_ZONE_SHELF_MAINTENANCE                                 ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_ACCOUNT_MANAGEMENT                                     ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_CLOSE_SYSTEM                                           ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_DEBUG                                                  ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_LOGIN                                                  ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_MTS_MTL_MAINTENANCE                                    ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_PORT_MAINTENANCE                                       ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_SYSTEM_CONCROL_MODE                                    ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_TRANSFER_MANAGEMENT                                    ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'ENG                 ', N'FUNC_VEHICLE_MANAGEMENT                                     ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_ACCOUNT_MANAGEMENT                                     ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_ADVANCED_SETTINGS                                      ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_CLOSE_SYSTEM                                           ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_DEBUG                                                  ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_LOGIN                                                  ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_MTS_MTL_MAINTENANCE                                    ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_PORT_MAINTENANCE                                       ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_SYSTEM_CONCROL_MODE                                    ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_TRANSFER_MANAGEMENT                                    ')
GO
INSERT [dbo].[UASUFNC] ([USER_GRP], [FUNC_CODE]) VALUES (N'TEST                ', N'FUNC_VEHICLE_MANAGEMENT                                     ')
GO
INSERT [dbo].[UASUSR] ([USER_ID], [BADGE_NUMBER], [USER_NAME], [DISABLE_FLG], [POWER_USER_FLG], [ADMIN_FLG], [USER_GRP], [DEPARTMENT], [PASSWD]) VALUES (N'ADMIN               ', N'123456                                                                          ', N'ADMI                          ', N'N', N'N', N'N', N'ADMIN               ', N'3K3                 ', N'123')
GO
INSERT [dbo].[UASUSR] ([USER_ID], [BADGE_NUMBER], [USER_NAME], [DISABLE_FLG], [POWER_USER_FLG], [ADMIN_FLG], [USER_GRP], [DEPARTMENT], [PASSWD]) VALUES (N'MARK                ', N'123456                                                                          ', N'ADMI                          ', N'N', N'N', N'N', N'ENG                 ', N'3K3                 ', N'a0369036')
GO
INSERT [dbo].[UASUSRGRP] ([USER_GRP]) VALUES (N'ADMIN               ')
GO
INSERT [dbo].[UASUSRGRP] ([USER_GRP]) VALUES (N'ENG                 ')
GO
INSERT [dbo].[UASUSRGRP] ([USER_GRP]) VALUES (N'OP                  ')
GO
INSERT [dbo].[ZoneDef] ([StockerID], [ZoneID], [ZoneName], [HighWaterMark], [LowWaterMark], [ZoneType], [InventoryCheck], [Color], [SourceWeighted], [DestWeighted], [Remark], [TrnDT]) VALUES (N'1', N'B7_OHBLINE2-ZONE1', N'B7_OHBLINE2-ZONE1', CAST(0 AS Numeric(5, 0)), CAST(0 AS Numeric(5, 0)), CAST(1 AS Numeric(2, 0)), N'Y', N'#000000', CAST(0 AS Numeric(2, 0)), CAST(0 AS Numeric(2, 0)), NULL, NULL)
GO
INSERT [dbo].[ZoneDef] ([StockerID], [ZoneID], [ZoneName], [HighWaterMark], [LowWaterMark], [ZoneType], [InventoryCheck], [Color], [SourceWeighted], [DestWeighted], [Remark], [TrnDT]) VALUES (N'1', N'B7_OHBLINE2-ZONE2', N'B7_OHBLINE2-ZONE2', CAST(1 AS Numeric(5, 0)), CAST(1 AS Numeric(5, 0)), CAST(1 AS Numeric(2, 0)), N'1', N'#FFFF80', CAST(1 AS Numeric(2, 0)), CAST(1 AS Numeric(2, 0)), N'1', N'1')
GO
